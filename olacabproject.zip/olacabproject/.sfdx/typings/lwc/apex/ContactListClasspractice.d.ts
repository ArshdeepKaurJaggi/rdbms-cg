declare module "@salesforce/apex/ContactListClasspractice.getContactList" {
  export default function getContactList(): Promise<any>;
}

({
	doAdd : function(component, event, helper) {
		var a=component.get('v.input1');
        var b=component.get('v.input2');
        //alert(parseInt(a)+parseInt(b));
        component.set('v.output',parseInt(a)+parseInt(b));
	},
    doSub : function(component, event, helper) {
		var a=component.get('v.input1');
        var b=component.get('v.input2');
        //alert(a-b);
        component.set('v.output',parseInt(a)-parseInt(b));
	},
    doMult : function(component, event, helper) {
		var a=component.get('v.input1');
        var b=component.get('v.input2');
        //alert(a*b);
        component.set('v.output',parseInt(a)*parseInt(b));
	},
    doDiv : function(component, event, helper) {
		var a=component.get('v.input1');
        var b=component.get('v.input2');
        //alert(a/b);
        component.set('v.output',parseInt(a)/parseInt(b));
	}
})
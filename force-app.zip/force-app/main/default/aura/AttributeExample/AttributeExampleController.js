({
	doClick : function(component, event, helper) {
		alert(component.getName());
        alert(component.isValid());
        component.set('v.whom',"hello");
        alert(component.get('v.whom'));
        var age=component.find('testinput');
        alert(age.get('v.value'));
        age.set('v.value',67);
        
        var map=[];
        for(var i=0;i<10;i++){
            map.push({
                key: i,
                value: 'Test'+i
            });
        }
        component.set('v.mapex',map);
	}
})
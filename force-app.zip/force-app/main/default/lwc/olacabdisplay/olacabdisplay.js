import { LightningElement, wire, track } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import { deleteRecord } from 'lightning/uiRecordApi';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import {refreshApex} from '@salesforce/apex';
import getrecords from '@salesforce/apex/olacabpracticecontroller.getrecords';
const col = [
    { label: 'Customername', fieldName:'CustomerName__c'},
    { label: 'Phone', fieldName: 'Phone__c' },
    { label: 'PickUp', fieldName: 'PickUpLocation__c' },
    { label: 'Drop', fieldName: 'DropLocation__c' }
];
export default class Olacabdisplay extends LightningElement {
    @track details;
    @track error;
    @track columns=col;
    @track record='';
    @wire(getrecords)
        wireddetailsofcab({error,data})
        {
            console.log('groot');
            if(data){
                this.details=data;
                this.error=undefined;
            }
            if(error){
                this.details=undefined;
                this.error=error;
            } 
        }
}